package io.turnbase.grpc.gamehost.v1;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Dispatch path. Served BY the Game Host; called BY the Orchestration Service.
 * Any Orchestration replica may call any of these RPCs against the Game Host
 * instance named in the Redis routing table for the session. Calls are unary:
 * one input in, one complete ordered effect list out, matching the game
 * handler's synchronous atomic contract (game-contracts.md FR-RESP-001a/004).
 * Per-session ordering is enforced by the Orchestration Service's Redis-backed
 * queue (FR-ROUTE-002), NOT by the transport. The Game Host deduplicates a
 * sequence at or below its watermark by replaying the recorded outcome, and
 * ACCEPTS forward gaps: a burned sequence from a failed input makes the stream
 * sparse by design (see ProcessInputRequest.sequence).
 * </pre>
 */
@io.grpc.stub.annotations.GrpcGenerated
public final class GameHostServiceGrpc {

  private GameHostServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "turnbase.gamehost.v1.GameHostService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.CreateSessionRequest,
      io.turnbase.grpc.gamehost.v1.CreateSessionResponse> getCreateSessionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateSession",
      requestType = io.turnbase.grpc.gamehost.v1.CreateSessionRequest.class,
      responseType = io.turnbase.grpc.gamehost.v1.CreateSessionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.CreateSessionRequest,
      io.turnbase.grpc.gamehost.v1.CreateSessionResponse> getCreateSessionMethod() {
    io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.CreateSessionRequest, io.turnbase.grpc.gamehost.v1.CreateSessionResponse> getCreateSessionMethod;
    if ((getCreateSessionMethod = GameHostServiceGrpc.getCreateSessionMethod) == null) {
      synchronized (GameHostServiceGrpc.class) {
        if ((getCreateSessionMethod = GameHostServiceGrpc.getCreateSessionMethod) == null) {
          GameHostServiceGrpc.getCreateSessionMethod = getCreateSessionMethod =
              io.grpc.MethodDescriptor.<io.turnbase.grpc.gamehost.v1.CreateSessionRequest, io.turnbase.grpc.gamehost.v1.CreateSessionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateSession"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.CreateSessionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.CreateSessionResponse.getDefaultInstance()))
              .setSchemaDescriptor(new GameHostServiceMethodDescriptorSupplier("CreateSession"))
              .build();
        }
      }
    }
    return getCreateSessionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.ProcessInputRequest,
      io.turnbase.grpc.gamehost.v1.ProcessInputResponse> getProcessInputMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ProcessInput",
      requestType = io.turnbase.grpc.gamehost.v1.ProcessInputRequest.class,
      responseType = io.turnbase.grpc.gamehost.v1.ProcessInputResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.ProcessInputRequest,
      io.turnbase.grpc.gamehost.v1.ProcessInputResponse> getProcessInputMethod() {
    io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.ProcessInputRequest, io.turnbase.grpc.gamehost.v1.ProcessInputResponse> getProcessInputMethod;
    if ((getProcessInputMethod = GameHostServiceGrpc.getProcessInputMethod) == null) {
      synchronized (GameHostServiceGrpc.class) {
        if ((getProcessInputMethod = GameHostServiceGrpc.getProcessInputMethod) == null) {
          GameHostServiceGrpc.getProcessInputMethod = getProcessInputMethod =
              io.grpc.MethodDescriptor.<io.turnbase.grpc.gamehost.v1.ProcessInputRequest, io.turnbase.grpc.gamehost.v1.ProcessInputResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ProcessInput"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.ProcessInputRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.ProcessInputResponse.getDefaultInstance()))
              .setSchemaDescriptor(new GameHostServiceMethodDescriptorSupplier("ProcessInput"))
              .build();
        }
      }
    }
    return getProcessInputMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.ResyncRequest,
      io.turnbase.grpc.gamehost.v1.ResyncResponse> getResyncMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Resync",
      requestType = io.turnbase.grpc.gamehost.v1.ResyncRequest.class,
      responseType = io.turnbase.grpc.gamehost.v1.ResyncResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.ResyncRequest,
      io.turnbase.grpc.gamehost.v1.ResyncResponse> getResyncMethod() {
    io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.ResyncRequest, io.turnbase.grpc.gamehost.v1.ResyncResponse> getResyncMethod;
    if ((getResyncMethod = GameHostServiceGrpc.getResyncMethod) == null) {
      synchronized (GameHostServiceGrpc.class) {
        if ((getResyncMethod = GameHostServiceGrpc.getResyncMethod) == null) {
          GameHostServiceGrpc.getResyncMethod = getResyncMethod =
              io.grpc.MethodDescriptor.<io.turnbase.grpc.gamehost.v1.ResyncRequest, io.turnbase.grpc.gamehost.v1.ResyncResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Resync"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.ResyncRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.ResyncResponse.getDefaultInstance()))
              .setSchemaDescriptor(new GameHostServiceMethodDescriptorSupplier("Resync"))
              .build();
        }
      }
    }
    return getResyncMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.TerminateSessionRequest,
      io.turnbase.grpc.gamehost.v1.TerminateSessionResponse> getTerminateSessionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "TerminateSession",
      requestType = io.turnbase.grpc.gamehost.v1.TerminateSessionRequest.class,
      responseType = io.turnbase.grpc.gamehost.v1.TerminateSessionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.TerminateSessionRequest,
      io.turnbase.grpc.gamehost.v1.TerminateSessionResponse> getTerminateSessionMethod() {
    io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.TerminateSessionRequest, io.turnbase.grpc.gamehost.v1.TerminateSessionResponse> getTerminateSessionMethod;
    if ((getTerminateSessionMethod = GameHostServiceGrpc.getTerminateSessionMethod) == null) {
      synchronized (GameHostServiceGrpc.class) {
        if ((getTerminateSessionMethod = GameHostServiceGrpc.getTerminateSessionMethod) == null) {
          GameHostServiceGrpc.getTerminateSessionMethod = getTerminateSessionMethod =
              io.grpc.MethodDescriptor.<io.turnbase.grpc.gamehost.v1.TerminateSessionRequest, io.turnbase.grpc.gamehost.v1.TerminateSessionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "TerminateSession"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.TerminateSessionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.TerminateSessionResponse.getDefaultInstance()))
              .setSchemaDescriptor(new GameHostServiceMethodDescriptorSupplier("TerminateSession"))
              .build();
        }
      }
    }
    return getTerminateSessionMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static GameHostServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<GameHostServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<GameHostServiceStub>() {
        @java.lang.Override
        public GameHostServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new GameHostServiceStub(channel, callOptions);
        }
      };
    return GameHostServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static GameHostServiceBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<GameHostServiceBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<GameHostServiceBlockingV2Stub>() {
        @java.lang.Override
        public GameHostServiceBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new GameHostServiceBlockingV2Stub(channel, callOptions);
        }
      };
    return GameHostServiceBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static GameHostServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<GameHostServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<GameHostServiceBlockingStub>() {
        @java.lang.Override
        public GameHostServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new GameHostServiceBlockingStub(channel, callOptions);
        }
      };
    return GameHostServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static GameHostServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<GameHostServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<GameHostServiceFutureStub>() {
        @java.lang.Override
        public GameHostServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new GameHostServiceFutureStub(channel, callOptions);
        }
      };
    return GameHostServiceFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Dispatch path. Served BY the Game Host; called BY the Orchestration Service.
   * Any Orchestration replica may call any of these RPCs against the Game Host
   * instance named in the Redis routing table for the session. Calls are unary:
   * one input in, one complete ordered effect list out, matching the game
   * handler's synchronous atomic contract (game-contracts.md FR-RESP-001a/004).
   * Per-session ordering is enforced by the Orchestration Service's Redis-backed
   * queue (FR-ROUTE-002), NOT by the transport. The Game Host deduplicates a
   * sequence at or below its watermark by replaying the recorded outcome, and
   * ACCEPTS forward gaps: a burned sequence from a failed input makes the stream
   * sparse by design (see ProcessInputRequest.sequence).
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * Create a new session: bind it to the (game_id, game_version) Truffle
     * context, invoke the game's onInit handler with the roster + parameters,
     * and return the initial effects. (FR-SESS-004, game-contracts.md FR-IN-002)
     * </pre>
     */
    default void createSession(io.turnbase.grpc.gamehost.v1.CreateSessionRequest request,
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.CreateSessionResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateSessionMethod(), responseObserver);
    }

    /**
     * <pre>
     * Process one input for an existing session: an action, player_joined, or
     * player_left event. Returns the ordered effect list produced by the handler.
     * (FR-IN-003/004/005, FR-ROUTE-002)
     * </pre>
     */
    default void processInput(io.turnbase.grpc.gamehost.v1.ProcessInputRequest request,
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.ProcessInputResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getProcessInputMethod(), responseObserver);
    }

    /**
     * <pre>
     * Compose the current view of the session for one viewer, by invoking the
     * game's read-only onResync handler. (game-contracts.md FR-IN-006/FR-RESP-005)
     * Deliberately NOT a ProcessInput variant: it mutates nothing. It allocates no
     * sequence, does not advance lastAppliedSequence, does not write the session
     * record, and does not touch the delivery watermark. The Orchestration Service
     * delivers the returned view to the requesting client only.
     * Ordering: the Game Host serves this under the session's single-flight lock,
     * so the view is computed against a consistent state and is stamped with the
     * sequence it reflects (as_of_sequence). This is the client's catch-up
     * mechanism at game start, on reconnection, and on mid-game join; see
     * ../api-design/websocket.md "Game Session Protocol".
     * </pre>
     */
    default void resync(io.turnbase.grpc.gamehost.v1.ResyncRequest request,
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.ResyncResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getResyncMethod(), responseObserver);
    }

    /**
     * <pre>
     * Force-terminate a session and free its local + Redis state. Used for host
     * kick / room close and for permanent failure after the retry limit.
     * (FR-SESS-005, FR-FAIL-005)
     * </pre>
     */
    default void terminateSession(io.turnbase.grpc.gamehost.v1.TerminateSessionRequest request,
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.TerminateSessionResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getTerminateSessionMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service GameHostService.
   * <pre>
   * Dispatch path. Served BY the Game Host; called BY the Orchestration Service.
   * Any Orchestration replica may call any of these RPCs against the Game Host
   * instance named in the Redis routing table for the session. Calls are unary:
   * one input in, one complete ordered effect list out, matching the game
   * handler's synchronous atomic contract (game-contracts.md FR-RESP-001a/004).
   * Per-session ordering is enforced by the Orchestration Service's Redis-backed
   * queue (FR-ROUTE-002), NOT by the transport. The Game Host deduplicates a
   * sequence at or below its watermark by replaying the recorded outcome, and
   * ACCEPTS forward gaps: a burned sequence from a failed input makes the stream
   * sparse by design (see ProcessInputRequest.sequence).
   * </pre>
   */
  public static abstract class GameHostServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return GameHostServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service GameHostService.
   * <pre>
   * Dispatch path. Served BY the Game Host; called BY the Orchestration Service.
   * Any Orchestration replica may call any of these RPCs against the Game Host
   * instance named in the Redis routing table for the session. Calls are unary:
   * one input in, one complete ordered effect list out, matching the game
   * handler's synchronous atomic contract (game-contracts.md FR-RESP-001a/004).
   * Per-session ordering is enforced by the Orchestration Service's Redis-backed
   * queue (FR-ROUTE-002), NOT by the transport. The Game Host deduplicates a
   * sequence at or below its watermark by replaying the recorded outcome, and
   * ACCEPTS forward gaps: a burned sequence from a failed input makes the stream
   * sparse by design (see ProcessInputRequest.sequence).
   * </pre>
   */
  public static final class GameHostServiceStub
      extends io.grpc.stub.AbstractAsyncStub<GameHostServiceStub> {
    private GameHostServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected GameHostServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new GameHostServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * Create a new session: bind it to the (game_id, game_version) Truffle
     * context, invoke the game's onInit handler with the roster + parameters,
     * and return the initial effects. (FR-SESS-004, game-contracts.md FR-IN-002)
     * </pre>
     */
    public void createSession(io.turnbase.grpc.gamehost.v1.CreateSessionRequest request,
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.CreateSessionResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateSessionMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Process one input for an existing session: an action, player_joined, or
     * player_left event. Returns the ordered effect list produced by the handler.
     * (FR-IN-003/004/005, FR-ROUTE-002)
     * </pre>
     */
    public void processInput(io.turnbase.grpc.gamehost.v1.ProcessInputRequest request,
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.ProcessInputResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getProcessInputMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Compose the current view of the session for one viewer, by invoking the
     * game's read-only onResync handler. (game-contracts.md FR-IN-006/FR-RESP-005)
     * Deliberately NOT a ProcessInput variant: it mutates nothing. It allocates no
     * sequence, does not advance lastAppliedSequence, does not write the session
     * record, and does not touch the delivery watermark. The Orchestration Service
     * delivers the returned view to the requesting client only.
     * Ordering: the Game Host serves this under the session's single-flight lock,
     * so the view is computed against a consistent state and is stamped with the
     * sequence it reflects (as_of_sequence). This is the client's catch-up
     * mechanism at game start, on reconnection, and on mid-game join; see
     * ../api-design/websocket.md "Game Session Protocol".
     * </pre>
     */
    public void resync(io.turnbase.grpc.gamehost.v1.ResyncRequest request,
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.ResyncResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getResyncMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Force-terminate a session and free its local + Redis state. Used for host
     * kick / room close and for permanent failure after the retry limit.
     * (FR-SESS-005, FR-FAIL-005)
     * </pre>
     */
    public void terminateSession(io.turnbase.grpc.gamehost.v1.TerminateSessionRequest request,
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.TerminateSessionResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getTerminateSessionMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service GameHostService.
   * <pre>
   * Dispatch path. Served BY the Game Host; called BY the Orchestration Service.
   * Any Orchestration replica may call any of these RPCs against the Game Host
   * instance named in the Redis routing table for the session. Calls are unary:
   * one input in, one complete ordered effect list out, matching the game
   * handler's synchronous atomic contract (game-contracts.md FR-RESP-001a/004).
   * Per-session ordering is enforced by the Orchestration Service's Redis-backed
   * queue (FR-ROUTE-002), NOT by the transport. The Game Host deduplicates a
   * sequence at or below its watermark by replaying the recorded outcome, and
   * ACCEPTS forward gaps: a burned sequence from a failed input makes the stream
   * sparse by design (see ProcessInputRequest.sequence).
   * </pre>
   */
  public static final class GameHostServiceBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<GameHostServiceBlockingV2Stub> {
    private GameHostServiceBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected GameHostServiceBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new GameHostServiceBlockingV2Stub(channel, callOptions);
    }

    /**
     * <pre>
     * Create a new session: bind it to the (game_id, game_version) Truffle
     * context, invoke the game's onInit handler with the roster + parameters,
     * and return the initial effects. (FR-SESS-004, game-contracts.md FR-IN-002)
     * </pre>
     */
    public io.turnbase.grpc.gamehost.v1.CreateSessionResponse createSession(io.turnbase.grpc.gamehost.v1.CreateSessionRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getCreateSessionMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Process one input for an existing session: an action, player_joined, or
     * player_left event. Returns the ordered effect list produced by the handler.
     * (FR-IN-003/004/005, FR-ROUTE-002)
     * </pre>
     */
    public io.turnbase.grpc.gamehost.v1.ProcessInputResponse processInput(io.turnbase.grpc.gamehost.v1.ProcessInputRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getProcessInputMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Compose the current view of the session for one viewer, by invoking the
     * game's read-only onResync handler. (game-contracts.md FR-IN-006/FR-RESP-005)
     * Deliberately NOT a ProcessInput variant: it mutates nothing. It allocates no
     * sequence, does not advance lastAppliedSequence, does not write the session
     * record, and does not touch the delivery watermark. The Orchestration Service
     * delivers the returned view to the requesting client only.
     * Ordering: the Game Host serves this under the session's single-flight lock,
     * so the view is computed against a consistent state and is stamped with the
     * sequence it reflects (as_of_sequence). This is the client's catch-up
     * mechanism at game start, on reconnection, and on mid-game join; see
     * ../api-design/websocket.md "Game Session Protocol".
     * </pre>
     */
    public io.turnbase.grpc.gamehost.v1.ResyncResponse resync(io.turnbase.grpc.gamehost.v1.ResyncRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getResyncMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Force-terminate a session and free its local + Redis state. Used for host
     * kick / room close and for permanent failure after the retry limit.
     * (FR-SESS-005, FR-FAIL-005)
     * </pre>
     */
    public io.turnbase.grpc.gamehost.v1.TerminateSessionResponse terminateSession(io.turnbase.grpc.gamehost.v1.TerminateSessionRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getTerminateSessionMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service GameHostService.
   * <pre>
   * Dispatch path. Served BY the Game Host; called BY the Orchestration Service.
   * Any Orchestration replica may call any of these RPCs against the Game Host
   * instance named in the Redis routing table for the session. Calls are unary:
   * one input in, one complete ordered effect list out, matching the game
   * handler's synchronous atomic contract (game-contracts.md FR-RESP-001a/004).
   * Per-session ordering is enforced by the Orchestration Service's Redis-backed
   * queue (FR-ROUTE-002), NOT by the transport. The Game Host deduplicates a
   * sequence at or below its watermark by replaying the recorded outcome, and
   * ACCEPTS forward gaps: a burned sequence from a failed input makes the stream
   * sparse by design (see ProcessInputRequest.sequence).
   * </pre>
   */
  public static final class GameHostServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<GameHostServiceBlockingStub> {
    private GameHostServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected GameHostServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new GameHostServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Create a new session: bind it to the (game_id, game_version) Truffle
     * context, invoke the game's onInit handler with the roster + parameters,
     * and return the initial effects. (FR-SESS-004, game-contracts.md FR-IN-002)
     * </pre>
     */
    public io.turnbase.grpc.gamehost.v1.CreateSessionResponse createSession(io.turnbase.grpc.gamehost.v1.CreateSessionRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateSessionMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Process one input for an existing session: an action, player_joined, or
     * player_left event. Returns the ordered effect list produced by the handler.
     * (FR-IN-003/004/005, FR-ROUTE-002)
     * </pre>
     */
    public io.turnbase.grpc.gamehost.v1.ProcessInputResponse processInput(io.turnbase.grpc.gamehost.v1.ProcessInputRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getProcessInputMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Compose the current view of the session for one viewer, by invoking the
     * game's read-only onResync handler. (game-contracts.md FR-IN-006/FR-RESP-005)
     * Deliberately NOT a ProcessInput variant: it mutates nothing. It allocates no
     * sequence, does not advance lastAppliedSequence, does not write the session
     * record, and does not touch the delivery watermark. The Orchestration Service
     * delivers the returned view to the requesting client only.
     * Ordering: the Game Host serves this under the session's single-flight lock,
     * so the view is computed against a consistent state and is stamped with the
     * sequence it reflects (as_of_sequence). This is the client's catch-up
     * mechanism at game start, on reconnection, and on mid-game join; see
     * ../api-design/websocket.md "Game Session Protocol".
     * </pre>
     */
    public io.turnbase.grpc.gamehost.v1.ResyncResponse resync(io.turnbase.grpc.gamehost.v1.ResyncRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getResyncMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Force-terminate a session and free its local + Redis state. Used for host
     * kick / room close and for permanent failure after the retry limit.
     * (FR-SESS-005, FR-FAIL-005)
     * </pre>
     */
    public io.turnbase.grpc.gamehost.v1.TerminateSessionResponse terminateSession(io.turnbase.grpc.gamehost.v1.TerminateSessionRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getTerminateSessionMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service GameHostService.
   * <pre>
   * Dispatch path. Served BY the Game Host; called BY the Orchestration Service.
   * Any Orchestration replica may call any of these RPCs against the Game Host
   * instance named in the Redis routing table for the session. Calls are unary:
   * one input in, one complete ordered effect list out, matching the game
   * handler's synchronous atomic contract (game-contracts.md FR-RESP-001a/004).
   * Per-session ordering is enforced by the Orchestration Service's Redis-backed
   * queue (FR-ROUTE-002), NOT by the transport. The Game Host deduplicates a
   * sequence at or below its watermark by replaying the recorded outcome, and
   * ACCEPTS forward gaps: a burned sequence from a failed input makes the stream
   * sparse by design (see ProcessInputRequest.sequence).
   * </pre>
   */
  public static final class GameHostServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<GameHostServiceFutureStub> {
    private GameHostServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected GameHostServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new GameHostServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Create a new session: bind it to the (game_id, game_version) Truffle
     * context, invoke the game's onInit handler with the roster + parameters,
     * and return the initial effects. (FR-SESS-004, game-contracts.md FR-IN-002)
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.turnbase.grpc.gamehost.v1.CreateSessionResponse> createSession(
        io.turnbase.grpc.gamehost.v1.CreateSessionRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateSessionMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Process one input for an existing session: an action, player_joined, or
     * player_left event. Returns the ordered effect list produced by the handler.
     * (FR-IN-003/004/005, FR-ROUTE-002)
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.turnbase.grpc.gamehost.v1.ProcessInputResponse> processInput(
        io.turnbase.grpc.gamehost.v1.ProcessInputRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getProcessInputMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Compose the current view of the session for one viewer, by invoking the
     * game's read-only onResync handler. (game-contracts.md FR-IN-006/FR-RESP-005)
     * Deliberately NOT a ProcessInput variant: it mutates nothing. It allocates no
     * sequence, does not advance lastAppliedSequence, does not write the session
     * record, and does not touch the delivery watermark. The Orchestration Service
     * delivers the returned view to the requesting client only.
     * Ordering: the Game Host serves this under the session's single-flight lock,
     * so the view is computed against a consistent state and is stamped with the
     * sequence it reflects (as_of_sequence). This is the client's catch-up
     * mechanism at game start, on reconnection, and on mid-game join; see
     * ../api-design/websocket.md "Game Session Protocol".
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.turnbase.grpc.gamehost.v1.ResyncResponse> resync(
        io.turnbase.grpc.gamehost.v1.ResyncRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getResyncMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Force-terminate a session and free its local + Redis state. Used for host
     * kick / room close and for permanent failure after the retry limit.
     * (FR-SESS-005, FR-FAIL-005)
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.turnbase.grpc.gamehost.v1.TerminateSessionResponse> terminateSession(
        io.turnbase.grpc.gamehost.v1.TerminateSessionRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getTerminateSessionMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CREATE_SESSION = 0;
  private static final int METHODID_PROCESS_INPUT = 1;
  private static final int METHODID_RESYNC = 2;
  private static final int METHODID_TERMINATE_SESSION = 3;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREATE_SESSION:
          serviceImpl.createSession((io.turnbase.grpc.gamehost.v1.CreateSessionRequest) request,
              (io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.CreateSessionResponse>) responseObserver);
          break;
        case METHODID_PROCESS_INPUT:
          serviceImpl.processInput((io.turnbase.grpc.gamehost.v1.ProcessInputRequest) request,
              (io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.ProcessInputResponse>) responseObserver);
          break;
        case METHODID_RESYNC:
          serviceImpl.resync((io.turnbase.grpc.gamehost.v1.ResyncRequest) request,
              (io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.ResyncResponse>) responseObserver);
          break;
        case METHODID_TERMINATE_SESSION:
          serviceImpl.terminateSession((io.turnbase.grpc.gamehost.v1.TerminateSessionRequest) request,
              (io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.TerminateSessionResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getCreateSessionMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              io.turnbase.grpc.gamehost.v1.CreateSessionRequest,
              io.turnbase.grpc.gamehost.v1.CreateSessionResponse>(
                service, METHODID_CREATE_SESSION)))
        .addMethod(
          getProcessInputMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              io.turnbase.grpc.gamehost.v1.ProcessInputRequest,
              io.turnbase.grpc.gamehost.v1.ProcessInputResponse>(
                service, METHODID_PROCESS_INPUT)))
        .addMethod(
          getResyncMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              io.turnbase.grpc.gamehost.v1.ResyncRequest,
              io.turnbase.grpc.gamehost.v1.ResyncResponse>(
                service, METHODID_RESYNC)))
        .addMethod(
          getTerminateSessionMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              io.turnbase.grpc.gamehost.v1.TerminateSessionRequest,
              io.turnbase.grpc.gamehost.v1.TerminateSessionResponse>(
                service, METHODID_TERMINATE_SESSION)))
        .build();
  }

  private static abstract class GameHostServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    GameHostServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return io.turnbase.grpc.gamehost.v1.GameHostProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("GameHostService");
    }
  }

  private static final class GameHostServiceFileDescriptorSupplier
      extends GameHostServiceBaseDescriptorSupplier {
    GameHostServiceFileDescriptorSupplier() {}
  }

  private static final class GameHostServiceMethodDescriptorSupplier
      extends GameHostServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    GameHostServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (GameHostServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new GameHostServiceFileDescriptorSupplier())
              .addMethod(getCreateSessionMethod())
              .addMethod(getProcessInputMethod())
              .addMethod(getResyncMethod())
              .addMethod(getTerminateSessionMethod())
              .build();
        }
      }
    }
    return result;
  }
}
