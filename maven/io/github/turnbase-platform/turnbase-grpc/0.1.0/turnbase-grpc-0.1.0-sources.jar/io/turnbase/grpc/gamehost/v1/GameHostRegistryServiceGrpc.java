package io.turnbase.grpc.gamehost.v1;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Control path. Served BY the Orchestration Service; called BY the Game Host.
 * Every RPC here mutates only Redis-backed registry state, so any Orchestration
 * replica behind the load balancer can service any call (FR-ORCH-006). This is
 * what lets the Game Host dial a single stable Orchestration ClusterIP while the
 * dispatch path still addresses individual Game Host pods.
 * </pre>
 */
@io.grpc.stub.annotations.GrpcGenerated
public final class GameHostRegistryServiceGrpc {

  private GameHostRegistryServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "turnbase.gamehost.v1.GameHostRegistryService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.RegisterRequest,
      io.turnbase.grpc.gamehost.v1.RegisterResponse> getRegisterMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Register",
      requestType = io.turnbase.grpc.gamehost.v1.RegisterRequest.class,
      responseType = io.turnbase.grpc.gamehost.v1.RegisterResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.RegisterRequest,
      io.turnbase.grpc.gamehost.v1.RegisterResponse> getRegisterMethod() {
    io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.RegisterRequest, io.turnbase.grpc.gamehost.v1.RegisterResponse> getRegisterMethod;
    if ((getRegisterMethod = GameHostRegistryServiceGrpc.getRegisterMethod) == null) {
      synchronized (GameHostRegistryServiceGrpc.class) {
        if ((getRegisterMethod = GameHostRegistryServiceGrpc.getRegisterMethod) == null) {
          GameHostRegistryServiceGrpc.getRegisterMethod = getRegisterMethod =
              io.grpc.MethodDescriptor.<io.turnbase.grpc.gamehost.v1.RegisterRequest, io.turnbase.grpc.gamehost.v1.RegisterResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Register"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.RegisterRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.RegisterResponse.getDefaultInstance()))
              .setSchemaDescriptor(new GameHostRegistryServiceMethodDescriptorSupplier("Register"))
              .build();
        }
      }
    }
    return getRegisterMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.HeartbeatRequest,
      io.turnbase.grpc.gamehost.v1.HeartbeatResponse> getHeartbeatMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Heartbeat",
      requestType = io.turnbase.grpc.gamehost.v1.HeartbeatRequest.class,
      responseType = io.turnbase.grpc.gamehost.v1.HeartbeatResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
  public static io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.HeartbeatRequest,
      io.turnbase.grpc.gamehost.v1.HeartbeatResponse> getHeartbeatMethod() {
    io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.HeartbeatRequest, io.turnbase.grpc.gamehost.v1.HeartbeatResponse> getHeartbeatMethod;
    if ((getHeartbeatMethod = GameHostRegistryServiceGrpc.getHeartbeatMethod) == null) {
      synchronized (GameHostRegistryServiceGrpc.class) {
        if ((getHeartbeatMethod = GameHostRegistryServiceGrpc.getHeartbeatMethod) == null) {
          GameHostRegistryServiceGrpc.getHeartbeatMethod = getHeartbeatMethod =
              io.grpc.MethodDescriptor.<io.turnbase.grpc.gamehost.v1.HeartbeatRequest, io.turnbase.grpc.gamehost.v1.HeartbeatResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Heartbeat"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.HeartbeatRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.HeartbeatResponse.getDefaultInstance()))
              .setSchemaDescriptor(new GameHostRegistryServiceMethodDescriptorSupplier("Heartbeat"))
              .build();
        }
      }
    }
    return getHeartbeatMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.ReportContextsRequest,
      io.turnbase.grpc.gamehost.v1.ReportContextsResponse> getReportContextsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ReportContexts",
      requestType = io.turnbase.grpc.gamehost.v1.ReportContextsRequest.class,
      responseType = io.turnbase.grpc.gamehost.v1.ReportContextsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.ReportContextsRequest,
      io.turnbase.grpc.gamehost.v1.ReportContextsResponse> getReportContextsMethod() {
    io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.ReportContextsRequest, io.turnbase.grpc.gamehost.v1.ReportContextsResponse> getReportContextsMethod;
    if ((getReportContextsMethod = GameHostRegistryServiceGrpc.getReportContextsMethod) == null) {
      synchronized (GameHostRegistryServiceGrpc.class) {
        if ((getReportContextsMethod = GameHostRegistryServiceGrpc.getReportContextsMethod) == null) {
          GameHostRegistryServiceGrpc.getReportContextsMethod = getReportContextsMethod =
              io.grpc.MethodDescriptor.<io.turnbase.grpc.gamehost.v1.ReportContextsRequest, io.turnbase.grpc.gamehost.v1.ReportContextsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ReportContexts"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.ReportContextsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.ReportContextsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new GameHostRegistryServiceMethodDescriptorSupplier("ReportContexts"))
              .build();
        }
      }
    }
    return getReportContextsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.DeregisterRequest,
      io.turnbase.grpc.gamehost.v1.DeregisterResponse> getDeregisterMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Deregister",
      requestType = io.turnbase.grpc.gamehost.v1.DeregisterRequest.class,
      responseType = io.turnbase.grpc.gamehost.v1.DeregisterResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.DeregisterRequest,
      io.turnbase.grpc.gamehost.v1.DeregisterResponse> getDeregisterMethod() {
    io.grpc.MethodDescriptor<io.turnbase.grpc.gamehost.v1.DeregisterRequest, io.turnbase.grpc.gamehost.v1.DeregisterResponse> getDeregisterMethod;
    if ((getDeregisterMethod = GameHostRegistryServiceGrpc.getDeregisterMethod) == null) {
      synchronized (GameHostRegistryServiceGrpc.class) {
        if ((getDeregisterMethod = GameHostRegistryServiceGrpc.getDeregisterMethod) == null) {
          GameHostRegistryServiceGrpc.getDeregisterMethod = getDeregisterMethod =
              io.grpc.MethodDescriptor.<io.turnbase.grpc.gamehost.v1.DeregisterRequest, io.turnbase.grpc.gamehost.v1.DeregisterResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Deregister"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.DeregisterRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.turnbase.grpc.gamehost.v1.DeregisterResponse.getDefaultInstance()))
              .setSchemaDescriptor(new GameHostRegistryServiceMethodDescriptorSupplier("Deregister"))
              .build();
        }
      }
    }
    return getDeregisterMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static GameHostRegistryServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<GameHostRegistryServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<GameHostRegistryServiceStub>() {
        @java.lang.Override
        public GameHostRegistryServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new GameHostRegistryServiceStub(channel, callOptions);
        }
      };
    return GameHostRegistryServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static GameHostRegistryServiceBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<GameHostRegistryServiceBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<GameHostRegistryServiceBlockingV2Stub>() {
        @java.lang.Override
        public GameHostRegistryServiceBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new GameHostRegistryServiceBlockingV2Stub(channel, callOptions);
        }
      };
    return GameHostRegistryServiceBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static GameHostRegistryServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<GameHostRegistryServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<GameHostRegistryServiceBlockingStub>() {
        @java.lang.Override
        public GameHostRegistryServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new GameHostRegistryServiceBlockingStub(channel, callOptions);
        }
      };
    return GameHostRegistryServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static GameHostRegistryServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<GameHostRegistryServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<GameHostRegistryServiceFutureStub>() {
        @java.lang.Override
        public GameHostRegistryServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new GameHostRegistryServiceFutureStub(channel, callOptions);
        }
      };
    return GameHostRegistryServiceFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Control path. Served BY the Orchestration Service; called BY the Game Host.
   * Every RPC here mutates only Redis-backed registry state, so any Orchestration
   * replica behind the load balancer can service any call (FR-ORCH-006). This is
   * what lets the Game Host dial a single stable Orchestration ClusterIP while the
   * dispatch path still addresses individual Game Host pods.
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * Announce availability on startup: dialable address + supported runtimes.
     * (FR-REG-001)
     * </pre>
     */
    default void register(io.turnbase.grpc.gamehost.v1.RegisterRequest request,
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.RegisterResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRegisterMethod(), responseObserver);
    }

    /**
     * <pre>
     * Bidirectional liveness stream. The Game Host emits periodic heartbeats that
     * refresh a TTL lease in Redis; the Orchestration Service may push back drain
     * instructions for graceful scale-in. The stream's state lives in Redis (the
     * lease), so a dropped stream is simply reconnected and is never authoritative.
     * (FR-REG-003, FR-ORCH-005, FR-SCALE-006)
     * </pre>
     */
    default io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.HeartbeatRequest> heartbeat(
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.HeartbeatResponse> responseObserver) {
      return io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall(getHeartbeatMethod(), responseObserver);
    }

    /**
     * <pre>
     * Report the full set of currently-loaded context keys so the Orchestration
     * Service can prefer a warm host when selecting where to create a session.
     * (FR-REG-002, FR-ORCH-004)
     * </pre>
     */
    default void reportContexts(io.turnbase.grpc.gamehost.v1.ReportContextsRequest request,
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.ReportContextsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getReportContextsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Graceful shutdown: stop routing new sessions to this instance. (FR-REG-004)
     * </pre>
     */
    default void deregister(io.turnbase.grpc.gamehost.v1.DeregisterRequest request,
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.DeregisterResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeregisterMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service GameHostRegistryService.
   * <pre>
   * Control path. Served BY the Orchestration Service; called BY the Game Host.
   * Every RPC here mutates only Redis-backed registry state, so any Orchestration
   * replica behind the load balancer can service any call (FR-ORCH-006). This is
   * what lets the Game Host dial a single stable Orchestration ClusterIP while the
   * dispatch path still addresses individual Game Host pods.
   * </pre>
   */
  public static abstract class GameHostRegistryServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return GameHostRegistryServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service GameHostRegistryService.
   * <pre>
   * Control path. Served BY the Orchestration Service; called BY the Game Host.
   * Every RPC here mutates only Redis-backed registry state, so any Orchestration
   * replica behind the load balancer can service any call (FR-ORCH-006). This is
   * what lets the Game Host dial a single stable Orchestration ClusterIP while the
   * dispatch path still addresses individual Game Host pods.
   * </pre>
   */
  public static final class GameHostRegistryServiceStub
      extends io.grpc.stub.AbstractAsyncStub<GameHostRegistryServiceStub> {
    private GameHostRegistryServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected GameHostRegistryServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new GameHostRegistryServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * Announce availability on startup: dialable address + supported runtimes.
     * (FR-REG-001)
     * </pre>
     */
    public void register(io.turnbase.grpc.gamehost.v1.RegisterRequest request,
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.RegisterResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRegisterMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Bidirectional liveness stream. The Game Host emits periodic heartbeats that
     * refresh a TTL lease in Redis; the Orchestration Service may push back drain
     * instructions for graceful scale-in. The stream's state lives in Redis (the
     * lease), so a dropped stream is simply reconnected and is never authoritative.
     * (FR-REG-003, FR-ORCH-005, FR-SCALE-006)
     * </pre>
     */
    public io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.HeartbeatRequest> heartbeat(
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.HeartbeatResponse> responseObserver) {
      return io.grpc.stub.ClientCalls.asyncBidiStreamingCall(
          getChannel().newCall(getHeartbeatMethod(), getCallOptions()), responseObserver);
    }

    /**
     * <pre>
     * Report the full set of currently-loaded context keys so the Orchestration
     * Service can prefer a warm host when selecting where to create a session.
     * (FR-REG-002, FR-ORCH-004)
     * </pre>
     */
    public void reportContexts(io.turnbase.grpc.gamehost.v1.ReportContextsRequest request,
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.ReportContextsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getReportContextsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Graceful shutdown: stop routing new sessions to this instance. (FR-REG-004)
     * </pre>
     */
    public void deregister(io.turnbase.grpc.gamehost.v1.DeregisterRequest request,
        io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.DeregisterResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeregisterMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service GameHostRegistryService.
   * <pre>
   * Control path. Served BY the Orchestration Service; called BY the Game Host.
   * Every RPC here mutates only Redis-backed registry state, so any Orchestration
   * replica behind the load balancer can service any call (FR-ORCH-006). This is
   * what lets the Game Host dial a single stable Orchestration ClusterIP while the
   * dispatch path still addresses individual Game Host pods.
   * </pre>
   */
  public static final class GameHostRegistryServiceBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<GameHostRegistryServiceBlockingV2Stub> {
    private GameHostRegistryServiceBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected GameHostRegistryServiceBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new GameHostRegistryServiceBlockingV2Stub(channel, callOptions);
    }

    /**
     * <pre>
     * Announce availability on startup: dialable address + supported runtimes.
     * (FR-REG-001)
     * </pre>
     */
    public io.turnbase.grpc.gamehost.v1.RegisterResponse register(io.turnbase.grpc.gamehost.v1.RegisterRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getRegisterMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Bidirectional liveness stream. The Game Host emits periodic heartbeats that
     * refresh a TTL lease in Redis; the Orchestration Service may push back drain
     * instructions for graceful scale-in. The stream's state lives in Redis (the
     * lease), so a dropped stream is simply reconnected and is never authoritative.
     * (FR-REG-003, FR-ORCH-005, FR-SCALE-006)
     * </pre>
     */
    @io.grpc.ExperimentalApi("https://github.com/grpc/grpc-java/issues/10918")
    public io.grpc.stub.BlockingClientCall<io.turnbase.grpc.gamehost.v1.HeartbeatRequest, io.turnbase.grpc.gamehost.v1.HeartbeatResponse>
        heartbeat() {
      return io.grpc.stub.ClientCalls.blockingBidiStreamingCall(
          getChannel(), getHeartbeatMethod(), getCallOptions());
    }

    /**
     * <pre>
     * Report the full set of currently-loaded context keys so the Orchestration
     * Service can prefer a warm host when selecting where to create a session.
     * (FR-REG-002, FR-ORCH-004)
     * </pre>
     */
    public io.turnbase.grpc.gamehost.v1.ReportContextsResponse reportContexts(io.turnbase.grpc.gamehost.v1.ReportContextsRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getReportContextsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Graceful shutdown: stop routing new sessions to this instance. (FR-REG-004)
     * </pre>
     */
    public io.turnbase.grpc.gamehost.v1.DeregisterResponse deregister(io.turnbase.grpc.gamehost.v1.DeregisterRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getDeregisterMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service GameHostRegistryService.
   * <pre>
   * Control path. Served BY the Orchestration Service; called BY the Game Host.
   * Every RPC here mutates only Redis-backed registry state, so any Orchestration
   * replica behind the load balancer can service any call (FR-ORCH-006). This is
   * what lets the Game Host dial a single stable Orchestration ClusterIP while the
   * dispatch path still addresses individual Game Host pods.
   * </pre>
   */
  public static final class GameHostRegistryServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<GameHostRegistryServiceBlockingStub> {
    private GameHostRegistryServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected GameHostRegistryServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new GameHostRegistryServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Announce availability on startup: dialable address + supported runtimes.
     * (FR-REG-001)
     * </pre>
     */
    public io.turnbase.grpc.gamehost.v1.RegisterResponse register(io.turnbase.grpc.gamehost.v1.RegisterRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRegisterMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Report the full set of currently-loaded context keys so the Orchestration
     * Service can prefer a warm host when selecting where to create a session.
     * (FR-REG-002, FR-ORCH-004)
     * </pre>
     */
    public io.turnbase.grpc.gamehost.v1.ReportContextsResponse reportContexts(io.turnbase.grpc.gamehost.v1.ReportContextsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getReportContextsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Graceful shutdown: stop routing new sessions to this instance. (FR-REG-004)
     * </pre>
     */
    public io.turnbase.grpc.gamehost.v1.DeregisterResponse deregister(io.turnbase.grpc.gamehost.v1.DeregisterRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeregisterMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service GameHostRegistryService.
   * <pre>
   * Control path. Served BY the Orchestration Service; called BY the Game Host.
   * Every RPC here mutates only Redis-backed registry state, so any Orchestration
   * replica behind the load balancer can service any call (FR-ORCH-006). This is
   * what lets the Game Host dial a single stable Orchestration ClusterIP while the
   * dispatch path still addresses individual Game Host pods.
   * </pre>
   */
  public static final class GameHostRegistryServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<GameHostRegistryServiceFutureStub> {
    private GameHostRegistryServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected GameHostRegistryServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new GameHostRegistryServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Announce availability on startup: dialable address + supported runtimes.
     * (FR-REG-001)
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.turnbase.grpc.gamehost.v1.RegisterResponse> register(
        io.turnbase.grpc.gamehost.v1.RegisterRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRegisterMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Report the full set of currently-loaded context keys so the Orchestration
     * Service can prefer a warm host when selecting where to create a session.
     * (FR-REG-002, FR-ORCH-004)
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.turnbase.grpc.gamehost.v1.ReportContextsResponse> reportContexts(
        io.turnbase.grpc.gamehost.v1.ReportContextsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getReportContextsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Graceful shutdown: stop routing new sessions to this instance. (FR-REG-004)
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.turnbase.grpc.gamehost.v1.DeregisterResponse> deregister(
        io.turnbase.grpc.gamehost.v1.DeregisterRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeregisterMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_REGISTER = 0;
  private static final int METHODID_REPORT_CONTEXTS = 1;
  private static final int METHODID_DEREGISTER = 2;
  private static final int METHODID_HEARTBEAT = 3;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_REGISTER:
          serviceImpl.register((io.turnbase.grpc.gamehost.v1.RegisterRequest) request,
              (io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.RegisterResponse>) responseObserver);
          break;
        case METHODID_REPORT_CONTEXTS:
          serviceImpl.reportContexts((io.turnbase.grpc.gamehost.v1.ReportContextsRequest) request,
              (io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.ReportContextsResponse>) responseObserver);
          break;
        case METHODID_DEREGISTER:
          serviceImpl.deregister((io.turnbase.grpc.gamehost.v1.DeregisterRequest) request,
              (io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.DeregisterResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_HEARTBEAT:
          return (io.grpc.stub.StreamObserver<Req>) serviceImpl.heartbeat(
              (io.grpc.stub.StreamObserver<io.turnbase.grpc.gamehost.v1.HeartbeatResponse>) responseObserver);
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getRegisterMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              io.turnbase.grpc.gamehost.v1.RegisterRequest,
              io.turnbase.grpc.gamehost.v1.RegisterResponse>(
                service, METHODID_REGISTER)))
        .addMethod(
          getHeartbeatMethod(),
          io.grpc.stub.ServerCalls.asyncBidiStreamingCall(
            new MethodHandlers<
              io.turnbase.grpc.gamehost.v1.HeartbeatRequest,
              io.turnbase.grpc.gamehost.v1.HeartbeatResponse>(
                service, METHODID_HEARTBEAT)))
        .addMethod(
          getReportContextsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              io.turnbase.grpc.gamehost.v1.ReportContextsRequest,
              io.turnbase.grpc.gamehost.v1.ReportContextsResponse>(
                service, METHODID_REPORT_CONTEXTS)))
        .addMethod(
          getDeregisterMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              io.turnbase.grpc.gamehost.v1.DeregisterRequest,
              io.turnbase.grpc.gamehost.v1.DeregisterResponse>(
                service, METHODID_DEREGISTER)))
        .build();
  }

  private static abstract class GameHostRegistryServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    GameHostRegistryServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return io.turnbase.grpc.gamehost.v1.GameHostProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("GameHostRegistryService");
    }
  }

  private static final class GameHostRegistryServiceFileDescriptorSupplier
      extends GameHostRegistryServiceBaseDescriptorSupplier {
    GameHostRegistryServiceFileDescriptorSupplier() {}
  }

  private static final class GameHostRegistryServiceMethodDescriptorSupplier
      extends GameHostRegistryServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    GameHostRegistryServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (GameHostRegistryServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new GameHostRegistryServiceFileDescriptorSupplier())
              .addMethod(getRegisterMethod())
              .addMethod(getHeartbeatMethod())
              .addMethod(getReportContextsMethod())
              .addMethod(getDeregisterMethod())
              .build();
        }
      }
    }
    return result;
  }
}
